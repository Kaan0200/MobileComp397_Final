This is the final project submission for EECS 397
Mobile Computing and Sensor Network

This project was written by 
Alan Kaan Atesoglu (aka43) and
Harry Nelken (hrn10)

The two folders contain the entire android application and the project files contains the slides for the presentation as well as the movie demo, and other demo resource pictures.

* Unfortunately due to the nature of our project the video recording for the demo does not contain sound as it was captured using the video capture which does not record audio output.  If you want to hear the sound from the application you have to run the application yourself.